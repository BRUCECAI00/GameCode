local MainPlayer = class("MainPlayer", function()
    return display.newLayer()
end)

local TanksData = import("..data.TanksData")
local MapObjectData = import("..data.MapObjectData")
local GiftDropRate = import("..data.GiftDropRate")
function  MainPlayer:testUpload()
    print("你看到我了吗")
    -- body
end
function MainPlayer:ctor(sceneId, levelId)
    self.isRun = true
    self.giftShowTime = 0

    -- 当其小于等于0时敌方坦克会活动
    -- self.time = 60*600
    self.time = 0
    self.sceneId = sceneId
    self.levelId = levelId
    self.dropGoldRate = GiftDropRate.getGoldRate(sceneId, levelId)
    self.dropGoldRange = GiftDropRate.getgoldRange(sceneId, levelId)
    self.dropBuffRate = GiftDropRate.getBuffRate(sceneId, levelId)

    if self.levelId == 15 then
        self.waveData = TanksData.getWaveData(self.sceneId)
        self.waveNum = 1
    end

    self.map = cc.TMXTiledMap:create("map/map" .. self.sceneId .. "_" .. self.levelId .. ".tmx")
    self:addChild(self.map)

    local layerNameTables = {"floor", "wall", "ceiling"}
    for i, v in ipairs(layerNameTables) do
        -- 抗锯齿
        self.map:getLayer(v):getTexture():setAntiAliasTexParameters()    --setAliasTexParameters() --setAntiAliasTexParameters()
    end

    MAP_C = self.map:getMapSize().width
    MAP_R = self.map:getMapSize().height
    self:testUpload()
    
end

function MainPlayer:startPlayerLayer()
    self.gift = require("app.sprites.SGift").new(math.random(8))
    self.gift:setVisible(true)
    self.map:addChild(self.gift, 10)

    self.wall = self.map:getLayer("wall")
    self.ceiling = self.map:getLayer("ceiling")
    local group = self.map:getObjectGroup("tanks")
    local objects = group:getObjects()
    self.tanks = {}
    self.bullets = {}
    self.enemyCount = 0
    local addLife = cc.UserDefault:getInstance():getIntegerForKey(KEY_ADD_LIFE, 0)
    -- test
    -- self.life = 2 + addLife
    self.life = 2 + addLife

    for i = 0, table.getn(objects)-1 do
        local dict = objects[i + 1]

        if dict ~= nil then
            local key = "type"
            local tankT = tonumber(dict[key])
            key = "count"
            local tankC = tonumber(dict[key])

            key = "x"
            local tankX = tonumber(dict[key])

            key = "y"
            local tankY = tonumber(dict[key])

            -- 坦克是否自己行动
            local auto = true
            -- tankT 为0 时为我方坦克
            if tankT == 0 then
                tankT = cc.UserDefault:getInstance():getIntegerForKey(KEY_PLAYER_ID ,1)
                auto = false
            else
                self.enemyCount = self.enemyCount + tankC
            end

            local index = i + 1

            local isBorn = true
            if self.waveData and index ~= 1 then
                local curTankType = self.waveData[index - 1][self.waveNum]
                if curTankType == -1 then
                    isBorn = false
                    self.enemyCount = self.enemyCount - 1
                end
            end

            self.tanks[index] = require("app.sprites.STank").new(
                tankT, tankX + MAP_W/2, tankY + MAP_H/2, index , auto, tankC, isBorn)
            self.map:addChild(self.tanks[index], 11)

            self.bullets[index] = require("app.sprites.SBullet").new(tankT, auto, self.tanks[index].ak, self)
            self.bullets[index]:setVisible(false)
            self.map:addChild(self.bullets[index], 12)

            if not auto and index ~= 1 then
                self.bullets[1], self.bullets[index] = self.bullets[index], self.bullets[1]
                self.tanks[1], self.tanks[index] = self.tanks[index], self.tanks[1]
                self.tanks[1].index, self.tanks[index].index = 1, index
            end
        end
    end
    self:runAction(cc.Follow:create(self.tanks[1], cc.rect(0, 0, MAP_C*MAP_W, MAP_R*MAP_H)))

    local function onInterval(dt)
        if self.isRun then
            if self.giftShowTime <= 0 then
                if self.gift:isVisible() then
                    self.gift:setVisible(false)
                end
            else
                self.giftShowTime = self.giftShowTime - 1
            end

            if self.rocker ~= nil and self.rocker.run then
                if self.tanks[1].activation then
                    self.tanks[1]:setDirection(self.rocker.state)
                    self:run(self.tanks[1])
                end
            end

            --	AI tanks
            if self.time <= 0 then
                for i, tank in ipairs(self.tanks) do
                    if tank:isVisible() and tank.auto and tank.activation then
                        if (not self:run(tank)) or math.random(100) < 2 then
                            --	改变方向
                            tank:setDirection(math.random(4))
                            --	发射子弹 30%
                            if math.random(100) < 30 then
                                self:shoot(i)
                            end
                        elseif math.random(100) < 3 then
                            self:shoot(i)
                        end
                    end
                end
            else
                self.time = self.time - 1
            end
        end
    end
    self:scheduleUpdateWithPriorityLua(onInterval, 0)
end

function MainPlayer:setRocker(rocker)
    self.rocker = rocker
end

function MainPlayer:shoot(index)
    if not self.bullets[index]:isVisible() then
        self.bullets[index]:run(self.tanks[index].state,
            self.tanks[index]:getPositionX(), self.tanks[index]:getPositionY())
        self.tanks[index]:fire()
    end
end

-- 检测增益
function MainPlayer:detectGift( tank )
    if not tank.auto
        and self.gift:isVisible()
        and cc.rectIntersectsRect(tank:getBoundingBox(), cc.rect(self.gift
        :getPositionX() - 10, self.gift:getPositionY() - 10, 10, 10)) then
        self.giftShowTime = 0
        local giftId = self.gift.id
        if giftId == 1 then
            tank:setInvincible(9)
        elseif giftId == 2 then
            tank:setBulletType(2)
        elseif giftId == 3 then
            tank:setBulletType(3)
        elseif giftId == 4 then
            tank:setSpeed(4)
        elseif giftId == 5 then
            tank:addBlood()
        elseif giftId == 6 then
            local coinNum = math.random(self.dropGoldRange[1], self.dropGoldRange[2])
            self:getParent():addCoin(coinNum)
        elseif giftId == 7 then
            self.time = 8 * 60
        elseif giftId == 8 then
            tank:setArmor(25)
        elseif giftId == 9 then
            local coinNum = math.random(self.dropGoldRange[1], self.dropGoldRange[2])
            self:getParent():addCoin(coinNum)
        end
        if giftId == 9 then
            cc.SimpleAudioEngine:getInstance():playEffect(GAME_SFX.coin)
        else
            cc.SimpleAudioEngine:getInstance():playEffect(GAME_SFX.gift)
            self:getParent():showGift(giftId)
        end
        self.gift:setVisible(false)
    end
end

function MainPlayer:run(tank)
    local state = tank.state
    local speed = tank.speed
    local c
    local r

    -- 检测增益
    self:detectGift(tank)

    local tX = tank:getPositionX()
    local tY = tank:getPositionY()

    --	1 W->(Up)	 3 S->(Down)     2 D->(Right)	 4 A->(Left)
    if state == 1 then
        c = math.floor(tX/MAP_W)
        r = MAP_R-1 - math.floor((tY + MAP_H/2)/MAP_H)
        if self:noWall(c, r) and self:noTank(tank) then
            local x = c*MAP_W + MAP_W/2
            if tX == x
                or (tX > x and self:noWall(c+1, r))
                or (tX < x and self:noWall(c-1, r)) then
                tank:setPosition(cc.p(tX, tY+speed))
                tank:setDirection(state)
            elseif tX > x then
                tank:setPosition(cc.p(tX-2, tY))
                tank:setDirection(4)
            elseif tX < x then
                tank:setPosition(cc.p(tX+2, tY))
                tank:setDirection(2)
            end
            return true
        else
            tank:setDirection(state)
            return false
        end
    elseif state == 2 then
        c = math.floor((tX+MAP_W/2)/MAP_W)
        r = MAP_R-1 - math.floor(tY/MAP_H)
        if self:noWall(c, r) and self:noTank(tank) then
            local y = (MAP_R-1 - r)*MAP_H + MAP_H/2
            if tY == y or (tY > y and self:noWall(c, r-1))
                or (tY < y and self:noWall(c, r+1)) then
                tank:setPosition(cc.p(tX+speed, tY))
                tank:setDirection(state)
            elseif tY > y  then
                tank:setPosition(cc.p(tX, tY-2))
                tank:setDirection(3)
            elseif tY < y  then
                tank:setPosition(cc.p(tX, tY+2))
                tank:setDirection(1)
            end
            return true
        else
            tank:setDirection(state)
            return false
        end
    elseif state == 3 then
        c = math.floor(tX/MAP_W)
        r = MAP_R-1 - math.floor((tY + MAP_H/2 )/MAP_H)
        r = r + 1
        if self:noWall(c, r) and self:noTank(tank) then
            local x = c*MAP_W + MAP_W/2
            if tX == x or (tX > x and self:noWall(c+1, r))
                or (tX < x and self:noWall(c-1, r)) then
                tank:setPosition(cc.p(tX, tY-speed))
                tank:setDirection(state)
            elseif tX > x  then
                tank:setPosition(cc.p(tX-2, tY))
                tank:setDirection(4)
            elseif tX < x  then
                tank:setPosition(cc.p(tX+2, tY))
                tank:setDirection(2)
            end
            return true
        else
            tank:setDirection(state)
            return false
        end
    elseif state == 4 then
        c = math.floor((tX+MAP_W/2)/MAP_W)
        r = MAP_R-1 - math.floor(tY/MAP_H)
        c = c - 1
        if self:noWall(c, r) and self:noTank(tank) then
            local y = (MAP_R-1 - r)*MAP_H + MAP_H/2
            if tY == y or (tY > y and self:noWall(c, r-1))
                or (tY < y and self:noWall(c, r+1)) then
                tank:setPosition(cc.p(tX-speed, tY))
                tank:setDirection(state)
            elseif tY > y  then
                tank:setPosition(cc.p(tX, tY-2))
                tank:setDirection(3)
            elseif tY < y  then
                tank:setPosition(cc.p(tX, tY+2))
                tank:setDirection(1)
            end
            return true
        else
            tank:setDirection(state)
            return false
        end
    end
end

function MainPlayer:playerShoot()
    local tank = self.tanks[1]
    if tank.activation then
        if tank.bulletType == 1 then
            self:shoot(self.tanks[1].index)
        elseif tank.bulletType == 2 then
            self:fireAttack()
        elseif tank.bulletType == 3 then
            self:laserAttack()
        else
            self:shoot(self.tanks[1].index)
        end
    end
end

function MainPlayer:enemyDie()
    self:getParent():addScore(50 + (self.sceneId-1)*20)
    self.enemyCount = self.enemyCount - 1
    self:getParent():setEnemyNum(self.enemyCount)
    if self.enemyCount == 0 then
        if self.levelId == 15 and self.waveNum ~= #self.waveData[1] then
            self.waveNum = self.waveNum + 1
            for i = 1, #self.waveData do
                if self.waveData[i][self.waveNum] ~= -1 then
                    if self.waveData[i][self.waveNum - 1] == -1 then
                        self.tanks[i + 1]:born()
                    end
                    self.tanks[i + 1]:satanDay(self.waveData[i][self.waveNum])
                    self.enemyCount = self.enemyCount + 1
                end
            end
            self:getParent():setEnemyNum(self.enemyCount)
            self:getParent():setlevelShow(self.waveNum)
        else
            self:getParent():showSuccess()
        end
    end
end

function MainPlayer:airAttack()
    -- 显示
    self:getParent():airAttacks()

    -- 逻辑
    local playerPosX = self.tanks[1]:getPositionX()
    local playerPosY = self.tanks[1]:getPositionY()

    for i, v in ipairs(self.tanks) do

        local enemyPosX = v:getPositionX()
        local enemyPosY = v:getPositionY()

        -- 通过playerTanksPoint得到视野边界
        -- 边界上下限与敌方坦克坐标对比得出敌方坦克是否在视野内
        local function isEnemyInView()
            local minBorderX = 0
            local maxBorderX = 0
            local minBorderY = 0
            local maxBorderY = 0

            --	取得 X上下 边界
            if playerPosX <= display.width/2 then
                minBorderX = 0
                maxBorderX = display.width + MAP_W/5
            elseif playerPosX >= MAP_C*MAP_W - display.width/2 then
                minBorderX = MAP_C*MAP_W - display.width
                -- minBorderX = playerPosX - display.width/2 - MAP_W/5
                maxBorderX = MAP_C*MAP_W
            else
                minBorderX = playerPosX - display.width/2 - MAP_W/5
                maxBorderX = playerPosX + display.width/2 + MAP_W/5
            end

            --	取得 Y上下 边界
            if playerPosY <= display.height/2 then
                minBorderY = 0
                maxBorderY = display.height + MAP_H/5
            elseif playerPosY >= MAP_R*MAP_H - display.height/2 then
                minBorderY = MAP_R*MAP_H - display.height
                -- minBorderY = playerPosY - display.height/2 - MAP_H/5
                maxBorderY = MAP_R*MAP_H
            else
                minBorderY = playerPosY - display.height/2 - MAP_H/5
                maxBorderY = playerPosY + display.height/2 + MAP_H/5
            end

            --	判断敌方坦克是否在视野之内
            if enemyPosX < minBorderX or enemyPosX > maxBorderX
                or enemyPosY < minBorderY or enemyPosY > maxBorderY then
                return false
            else
                return true
            end

        end

        if v.auto and v:isVisible() and isEnemyInView() then
            self:runAction(
                cc.Sequence:create(
                    cc.DelayTime:create(math.random(10, 12)/10),
                    cc.CallFunc:create(function ()
                        v:mustDie()
                        self:enemyDie()
                    end)
                )
            )
        end
    end
end

function MainPlayer:laserAttack()
    local tank = self.tanks[1]
    local bullet3 = require("app.sprites.SBullet3").new(
        tank.state
        , tank:getPositionX()
        , tank:getPositionY()
        , self
        , tank.ak )
    self:addChild(bullet3)
end

function MainPlayer:fireAttack()
    local tank = self.tanks[1]
    if tank.canShoot then
        tank.canShoot = false
        local bullet2 = require("app.sprites.SBullet2").new(
            tank.state
            , tank:getPositionX()
            , tank:getPositionY()
            , self
            , tank.ak )
        self:addChild(bullet2)
    end
end

function MainPlayer:setPlayerState(state)
    if self.tanks[1].activation then
        self.tanks[1]:setDirection(state)
        self:run(self.tanks[1])
    end
end

function MainPlayer:revivePlayer()
    self.tanks[1]:revive()
end

function MainPlayer:hitWall(c, r, auto)
    if c >= 0 and c <= MAP_C-1
        and r >= 0 and r <= MAP_R-1 then
        local w = self.wall:getTileAt(cc.p(c, r))
        if w and w:isVisible() then
            self:removeWall(c, r, auto)
            return true
        end
    end
    return false
end
local function  ocCallBack(str)
   
    print("MainPlayer:ocCallBack")
    -- cc.Director:getInstance().getApp():pay("pay" .. str)
  
 
 end
 function MainPlayer:showAdVideo()
     local luaoc = require("cocos.cocos2d.luaoc")
     local className = "RootViewController" 
     local methodName = "showAdVideo"
     local args ={callBack = ocCallBack,a = "aa"}
     luaoc.callStaticMethod(className, methodName, args)
 end
function MainPlayer:hitTank(auto, x, y, ak)
    --	这里的auto是子弹是否是auto坦克发射的
    if auto then
        local tank = self.tanks[1]
        if tank:isVisible() and tank.activation
            and cc.rectContainsPoint(tank:getBoundingBox(), cc.p(x, y)) then
            if tank:setDeath(ak) then
                self.life = self.life - 1
                if self.life < 0 then
                    self.life = 0
                end
                self:getParent():setLife(self.life)
                if self.life == 0 then
                    -- 1-ReviveDialog, 2-MainPopDialog
                       self:showAdVideo()
                    self:getParent():showFail(1)
                else
                    tank:revive()
                end
            end
            return true
        end

    --	Player发射的子弹在这里，判断是否与AI坦克碰撞
    else
        for i = 2, #self.tanks do
            local tank = self.tanks[i]
            if tank:isVisible() and tank.activation
                and cc.rectContainsPoint(tank:getBoundingBox(), cc.p(x, y)) then
                if tank:setDeath(ak) then
                    self:createGift()
                    self:enemyDie()
                end
                return true
            end
        end
    end
    return false
end

function MainPlayer:setLife(lifeNum)
    self.life = lifeNum
end




function MainPlayer:setShootEnable(index, enable)
    self.tanks[index]:setShootEnable(true)
end

function MainPlayer:callRandomBombInMap()
    for i = 1, math.random(4, 10) do
        self:runAction(
            cc.Sequence:create(
                cc.DelayTime:create(math.random(10, 70)/100),
                cc.CallFunc:create(function ()
                    cc.SimpleAudioEngine:getInstance():playEffect(GAME_SFX.bomb)

                    local bomb = display.newSprite("#bomb1.png",
                        self.tanks[1]:getPositionX() + math.random(-480, 480),
                        self.tanks[1]:getPositionY() + math.random(-300, 300))
                    self:addChild(bomb)
                    bomb:setScale(4)
                    bomb:runAction(cc.Sequence:create(
                        cc.Animate:create(cc.AnimationCache:getInstance():getAnimation("bomb")),
                        cc.CallFunc:create(function (node)
                            node:removeFromParent(true)
                        end)))
                end)   
            )
        )
    end
end


function MainPlayer:createGift(wC, wR)
    if not self.gift:isVisible() then
        local r = math.random(100)
        local function showGiftWithId(id)
            self.gift:setId(id)
            self.gift:setPosition(cc.p(wC * MAP_W + MAP_W/2, (MAP_R-1-wR)*MAP_H + MAP_H/2))
            self.gift:setVisible(true)
            self.giftShowTime = 10 * 60
        end
        if r <= self.dropGoldRate then
            showGiftWithId(9)
        elseif r <= self.dropGoldRate + self.dropBuffRate then
            local giftType = math.random(8)

            -- 剔除激光武器
            repeat
                giftType = math.random(8)
            until giftType ~= 3

            showGiftWithId(giftType)
        end
    end
end

function MainPlayer:removeWall(c, r, auto)
    cc.SimpleAudioEngine:getInstance():playEffect(GAME_SFX.bomb)

    local bomb = display.newSprite("#bomb1.png", c*MAP_W + MAP_W/2, (MAP_R-1-r)*MAP_H + MAP_H/2)
    self:addChild(bomb, 5)
    bomb:runAction(cc.Sequence:create(
        cc.Animate:create(cc.AnimationCache:getInstance():getAnimation("bomb")),
        cc.CallFunc:create(function (node)
            node:removeFromParent(true)
        end)))

    local function removeCeiling( tC, tR )
        if 0 <= tC and tC <= MAP_C - 1 and 0 <= tR and tR <= MAP_R - 1
            and self.ceiling:getTileAt(cc.p(tC, tR)) then
            self.ceiling:getTileAt(cc.p(tC, tR)):setVisible(false)
        end
    end

    local function removeWall( tC, tR )
        if 0 <= tC and tC <= MAP_C - 1 and 0 <= tR and tR <= MAP_R - 1
            and self.wall:getTileAt(cc.p(tC, tR)) then
            self.wall:getTileAt(cc.p(tC, tR)):setVisible(false)
            self:createGift(tC, tR)
            if not auto then
                self:getParent():addScore(10 + self.sceneId * 10)
            end
        end
    end

    local function setCellingGID( id, tC, tR )
        if 0 <= tC and tC <= MAP_C - 1 and 0 <= tR and tR <= MAP_R - 1
            and self.ceiling:getTileAt(cc.p(tC, tR)) then
            self.ceiling:setTileGID(id, cc.p(tC, tR))
        end
    end

    local function setWallGID( id, tC, tR )
        if 0 <= tC and tC <= MAP_C - 1 and 0 <= tR and tR <= MAP_R - 1
            and self.wall:getTileAt(cc.p(tC, tR)) then
            self.wall:setTileGID(id, cc.p(tC, tR))
        end
    end

    local id = self.wall:getTileGIDAt(cc.p(c, r))

    local wallData = MapObjectData.getWallData(self.sceneId)

    if wallData[id] then
        local wallType = MapObjectData.getWallType(wallData[id].mtype)
        if wallType.delete then
            if wallType.delete.center then removeWall(c, r) end
            if wallType.delete.up then removeCeiling(c, r - 1) end
            if wallType.delete.left then removeWall(c - 1, r) end
            if wallType.delete.right then removeWall(c + 1, r) end
            if wallType.delete.upRight then removeCeiling(c + 1, r - 1) end
            if wallType.delete.upLeft then removeCeiling(c - 1, r - 1) end
        end
        if wallType.change then
            if wallType.change.center then
                setWallGID(wallData[id].change.center, c, r)
            end
            if wallType.change.up then
                setCellingGID(wallData[id].change.up, c, r - 1)
            end
            if wallType.change.left then
                setWallGID(wallData[id].change.left, c - 1, r)
            end
            if wallType.change.right then
                setWallGID(wallData[id].change.right, c + 1, r)
            end
            if wallType.change.upRight then
                setCellingGID(wallData[id].change.upRight, c + 1, r - 1)
            end
            if wallType.change.upLeft then
                setCellingGID(wallData[id].change.upLeft, c - 1, r - 1)
            end
        end
    end
end

function MainPlayer:noWall(c, r)
    local ret = false

    if c >= 0 and c <= MAP_C - 1
        and r >= 0 and r <= MAP_R - 1 then
        local w = self.wall:getTileAt(cc.p(c, r))
        if w == nil or not w:isVisible() then
            ret = true
        end
    end

    return ret
end

function MainPlayer:noTank(tank)
    local ret = true

    local tankX = tank:getPositionX()
    local tankY = tank:getPositionY()
    local index = tank.index
    for i, v in ipairs(self.tanks) do
        if index ~= i and v:isVisible() then
            local vX = v:getPositionX()
            local vY = v:getPositionY()
            local b = cc.rectIntersectsRect(tank:getBoundingBox(), cc.rect(vX - 70/2, vY - 70/2, 70, 70))
            if b then
                local state = tank:getState()
                local x = tankX - vX
                local y = tankY - vY
                if  ( state == 1 and y < 0 ) or
                    ( state == 2 and x < 0 ) or
                    ( state == 3 and y > 0 ) or
                    ( state == 4 and x > 0 ) then
                    ret = false
                end
            end
        end
    end

    return ret
end

return MainPlayer